<a target="__blank" href="/" style="width: 100%">

    <img src="{{ asset('storage/'.getSetting('logo')) }}" alt="Logo">
</a>
